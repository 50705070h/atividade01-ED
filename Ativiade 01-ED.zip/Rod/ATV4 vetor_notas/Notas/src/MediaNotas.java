public class MediaNotas {
    public static void main(String[] args) {

        double[] notas = { 7.5, 8.0, 9.2, 6.8 };

        double soma = 0.0;
        for (double n : notas) {
            soma += n;
        }
        double media = soma / notas.length;

        System.out.printf("Notas: ");
        for (double n : notas) {
            System.out.print(n + " ");
        }
        System.out.println();
        System.out.printf("Média é : %.2f%n", media);
    }
}