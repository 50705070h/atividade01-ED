public class Exercicio1 {
    public static void main(String[] args) {
        int[] idades = { 12, 20, 5, 33, 17, 21, 9, 18, 25, 14 };

        System.out.println("Idades maiores que 18:");
        for (int idade : idades) {
            if (idade > 18) {
                System.out.println(idade);
            }
        }
    }
}