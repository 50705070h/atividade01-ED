import java.util.Scanner;

public class MaiorNota {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] notas = new int[10];
        int maior = Integer.MIN_VALUE;
        int menor = Integer.MAX_VALUE;

        System.out.println("Digite as notas dos 10 alunos:");
        for (int i = 0; i < notas.length; i++) {
            System.out.print("Aluno " + (i + 1) + ": ");
            notas[i] = sc.nextInt();

            if (notas[i] > maior) {
                maior = notas[i];
            }
            if (notas[i] < menor) {
                menor = notas[i];
            }
        }

        System.out.println("A maior nota é: " + maior);
        System.out.println("A menor nota é: " + menor);
        sc.close();
    }
}